﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using DAL1;
using Exceptions;

namespace BAL
{
    public class EmployerBAL
    {
        EmployerDAL Employerdal = new EmployerDAL();
        public bool Register(Er_Sign er_Sign)
        {
            try
            {
                return Employerdal.Register(er_Sign);
            }
            catch(EmployerNotValidDataException ex)
            {
                throw ex;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool login(Er_Sign er_Sign)
        {
            try
            {
                return Employerdal.login(er_Sign);
            }
            catch (EmployerNotValidDataException ex)
            {
                throw ex;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ResetPassword(Er_Sign er_Sign)
        {
            try
            {
                return Employerdal.ResetPassword(er_Sign);
            }
            catch (EmployerNotValidDataException ex)
            {
                throw ex;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Profile_Fill(Er_profile er_profile)
        {
            try
            {
                return Employerdal.Profile_Fill(er_profile);
            }
            catch (EmployerNotValidDataException ex)
            {
                throw ex;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
