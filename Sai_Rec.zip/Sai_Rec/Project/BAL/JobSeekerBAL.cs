﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Entities;
using DAL1;
using Exceptions;

namespace BAL
{
    public class JobSeekerBAL
    {
        JobSeekerDAL Jobseekerdal = new JobSeekerDAL();
        public bool Register(Js_Sign js_Sign)
        {
            try
            {
                return Jobseekerdal.Register(js_Sign);
            }
            catch(JobSeekerNotValidDataException ex)
            {
                throw ex;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool login(Js_Sign js_Sign)
        {
            try
            {
                return Jobseekerdal.login(js_Sign);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                throw ex;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool  ResetPassword(Js_Sign js_Sign)
        {
            try
            {
                return Jobseekerdal.ResetPassword(js_Sign);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                throw ex;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Profile_fill(Js_profile js_profile)
        {
            try
            {
                return Jobseekerdal.Profile_fill(js_profile);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                throw ex;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable RetrieveJobs()
        {
            try
            {
                return Jobseekerdal.RetrieveJobs();
            }
            catch (JobSeekerNotValidDataException ex)
            {
                throw ex;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Js_profile RetrieveMyProfile()
        {
            try
            {
                return Jobseekerdal.RetrieveMyProfile();
            }
            catch (JobSeekerNotValidDataException ex)
            {
                throw ex;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable SearchJob(Job_Profile job_profile)
        {
            try
            {
                return Jobseekerdal.SearchJob(job_profile);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                throw ex;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable MyApplications(string userId)
        {
            try
            {
                return Jobseekerdal.MyApplications(userId);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                throw ex;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
