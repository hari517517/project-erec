﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
   public class EmployerNotValidDataException : ApplicationException
    {
        public EmployerNotValidDataException(string message):base (message)
        {

        }
      
    }
   
    public class EmployerException:ApplicationException
    {
        public EmployerException():base()
        {

        }
        public EmployerException(string message):base(message)
        {

        }
    }
}
