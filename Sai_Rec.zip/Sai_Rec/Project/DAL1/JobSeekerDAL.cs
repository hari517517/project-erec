﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entities;
using Exceptions;


namespace DAL1
{
    public class JobSeekerDAL
    {

        SqlCommand cmd; SqlDataReader dr; SqlConnection con;DataTable dt; 
        public bool Register(Js_Sign js_Sign)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.js_sign_up_172473";
                cmd.Parameters.AddWithValue("@js_userid", Js_Sign.UserId);
                cmd.Parameters.AddWithValue("@js_password", js_Sign.Password1);
                cmd.Parameters.AddWithValue("@secureanswer", js_Sign.Securekey);
                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();
               
                if (ra > 0)
                { return true; }
                else
                { return false; }
            }
            catch(JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
            
        }

        public DataTable RetrieveJobs()
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.usp_retrieve_job_advs_172473";

                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                return dt;
            }            
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public DataTable MyApplications(string userId)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.usp_my_applications_js_172473";
                cmd.Parameters.AddWithValue("@js_userId", Js_Sign.UserId);
                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                
                return dt;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public DataTable SearchJob(Job_Profile job_profile)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "usp_job_search_for_js_172473";
                cmd.Parameters.AddWithValue("@experience", job_profile.Experience);
                cmd.Parameters.AddWithValue("@designation", job_profile.Designation);
                cmd.Parameters.AddWithValue("@location", job_profile.Location);
                cmd.Parameters.AddWithValue("@qualification", job_profile.Qualification);
                cmd.Parameters.AddWithValue("@date_of_openings", job_profile.DateOfOpening);
                cmd.Parameters.AddWithValue("@salary", job_profile.Salary);

                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                
                return dt;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }
       
        public Js_profile RetrieveMyProfile()
        {
            try
            {
                Js_profile jsprofile = new Js_profile();
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.Retrieve_JS_profile_172473";
                cmd.Parameters.AddWithValue("@js_userId", Js_Sign.UserId);
                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    jsprofile.Name = dr["Name"].ToString();
                    jsprofile.Experience = Convert.ToInt32(dr["experience"].ToString());
                    jsprofile.Gender = Convert.ToChar(dr["gender"].ToString());
                    jsprofile.Dob = Convert.ToDateTime(dr["dob"].ToString());
                    jsprofile.Email = dr["email"].ToString();
                    jsprofile.Phone = dr["phone"].ToString();
                    jsprofile.Skills = dr["skills"].ToString();
                    jsprofile.Address = dr["address"].ToString();
                    jsprofile.Qualification = dr["qualification"].ToString();
                    jsprofile.Photo = dr["photo"].ToString();
                    jsprofile.CV = dr["cv"].ToString();
                }
                
                return jsprofile;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }
        

        public bool Profile_fill(Js_profile js_profile)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.js_profile_fill_172473";
                cmd.Parameters.AddWithValue("@js_userid", Js_Sign.UserId);
                cmd.Parameters.AddWithValue("@Name", js_profile.Name);
                cmd.Parameters.AddWithValue("@experience", js_profile.Experience);
                cmd.Parameters.AddWithValue("@gender", js_profile.Gender);
                cmd.Parameters.AddWithValue("@dob", js_profile.Dob);
                cmd.Parameters.AddWithValue("@email", js_profile.Email);
                cmd.Parameters.AddWithValue("@phone", js_profile.Phone);
                cmd.Parameters.AddWithValue("@address", js_profile.Address);
                cmd.Parameters.AddWithValue("@skills", js_profile.Skills);
                cmd.Parameters.AddWithValue("@qualification", js_profile.Qualification);
                cmd.Parameters.AddWithValue("@photo", js_profile.Photo);
                cmd.Parameters.AddWithValue("@cv", js_profile.CV);
                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();
               
                if (ra > 0)
                { return true; }
                else
                { return false; }
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

  
        public bool ResetPassword(Js_Sign js_Sign)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.js_rst_pswd_172473";
                cmd.Parameters.AddWithValue("@js_userid", Js_Sign.UserId);
                cmd.Parameters.AddWithValue("@newpswd", js_Sign.Password1);
                cmd.Parameters.AddWithValue("@secure_answer", js_Sign.Securekey);
                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();
                if (ra > 0)
                { return true; }
                else
                { return false; }
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }

        public bool login(Js_Sign js_Sign)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.usp_check_login_for_js_172473";
                cmd.Parameters.AddWithValue("@js_userid", Js_Sign.UserId);
                cmd.Parameters.AddWithValue("@js_password", js_Sign.Password1);
                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr["Result"].ToString() == "YES")
                { return true; }
                else if (dr["Result"].ToString() == "NO")
                { return false; }
                return false;
            }
            catch (JobSeekerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }
    }
}
