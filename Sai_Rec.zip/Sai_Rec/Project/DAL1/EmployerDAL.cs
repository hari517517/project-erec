﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Entities;
using Exceptions;

namespace DAL1
{
    public class EmployerDAL
    {
        SqlCommand cmd; SqlDataReader dr;SqlConnection con;
        public bool Register(Er_Sign er_Sign)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.er_sign_up_172473";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                cmd.Parameters.AddWithValue("@er_password", er_Sign.Password1);
                cmd.Parameters.AddWithValue("@secureanswer", er_Sign.Securekey);
                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();
               
                if (ra > 0)
                { return true; }
                else
                { return false; }
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }

        }

        public bool Profile_Fill(Er_profile er_profile)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.er_rst_pswd_172473";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                cmd.Parameters.AddWithValue("@company_name", er_profile.CompanyName);
                cmd.Parameters.AddWithValue("@clients", er_profile.Clients);
                cmd.Parameters.AddWithValue("@location", er_profile.Location);
                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();
                if (ra > 0)
                { return true; }
                return false;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }
       
        public bool ResetPassword(Er_Sign er_Sign)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.er_rst_pswd_172473";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                cmd.Parameters.AddWithValue("@newpswd", er_Sign.Password1);
                cmd.Parameters.AddWithValue("@secure_answer", er_Sign.Securekey);

                con = cmd.Connection;
                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();
                if (ra > 0)
                { return true; }
                return false;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }
       

        public bool login(Er_Sign er_Sign)
        {
            try
            {
                cmd = DatabaseConnection.GenerateCommand();
                cmd.CommandText = "E_rec.er_sign_up_172473";
                cmd.Parameters.AddWithValue("@er_userid", Er_Sign.UserId);
                cmd.Parameters.AddWithValue("@er_password", er_Sign.Password1);

                con = cmd.Connection;
                con.Open();
                dr = cmd.ExecuteReader();
                con.Close();
                if (dr["Result"].ToString() == "YES")
                { return true; }
                else if (dr["Result"].ToString() == "NO")
                { return false; }
                return false;
            }
            catch (EmployerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { con.Close(); }
        }
    }
}
