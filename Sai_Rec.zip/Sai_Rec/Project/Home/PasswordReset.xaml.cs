﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using BAL;
using Exceptions;

namespace Home
{
    /// <summary>
    /// Interaction logic for PasswordReset.xaml
    /// </summary>
    public partial class PasswordReset : Window
    {
        Js_Sign js_Sign = new Js_Sign();

        Er_Sign er_Sign = new Er_Sign();

        EmployerBAL Employerbal = new EmployerBAL();

        JobSeekerBAL Jobseekerbal = new JobSeekerBAL();
        public PasswordReset()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (MainWindow.possition == "Employer")
            {
                EmployerResetPswrd.Visibility = 0;
            }
            else if (MainWindow.possition == "JobSeeker")
            {
                JobSeekerResetPswrd.Visibility = 0;
            }
        }

       

        private void Change_Pswd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MainWindow.possition == "Employer")
                {
                    Er_Sign.UserId = txtuserider.Text;
                    er_Sign.Password1 = newpsswrder.Password;
                    er_Sign.Password2 = cnfpsswrder.Password;
                    er_Sign.Securekey = txtsecureer.Text;
                    if (Employerbal.ResetPassword(er_Sign))
                    { MessageBox.Show("Password is successfully changed"); }
                    else
                    { MessageBox.Show("Sorry Your Credentials are Wrong"); }
                }
                else if (MainWindow.possition == "JobSeeker")
                {
                    Js_Sign.UserId = txtuseridjs.Text;
                    js_Sign.Securekey = txtsecurejs.Text;
                    js_Sign.Password1 = newpsswrdjs.Password;
                    js_Sign.Password2 = cnfpsswrdjs.Password;
                    if (Jobseekerbal.ResetPassword(js_Sign))
                    { MessageBox.Show("Password is successfully changed"); }
                    else
                    { MessageBox.Show("Sorry Your Credentials are Wrong"); }
                }
                LoginWindow P = new LoginWindow();
                P.Show();
                this.Close();
            }
            catch (EmployerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
