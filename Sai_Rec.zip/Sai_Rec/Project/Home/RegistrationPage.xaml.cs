﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using BAL;
using Exceptions;

namespace Home
{
    /// <summary>
    /// Interaction logic for RegistrationPage.xaml
    /// </summary>
    public partial class RegistrationPage : Window
    {
        Js_Sign js_Sign = new Js_Sign();

        Er_Sign er_Sign = new Er_Sign();


        EmployerBAL Employerbal = new EmployerBAL();

        JobSeekerBAL Jobseekerbal = new JobSeekerBAL();

        public RegistrationPage()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (MainWindow.possition == "Employer")
            {
                erreggrid.Visibility = 0;
            }
            else if (MainWindow.possition == "JobSeeker")
            {
                jsreggrid.Visibility = 0;
            }
        }

       
        private void Button_Click_Back(object sender, RoutedEventArgs e)
        {
            LoginWindow p = new LoginWindow();
            p.Show(); this.Close();
        }

        
        
        private void Button_Click_submit(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MainWindow.possition == "Employer")
                {
                    Er_Sign.UserId = txtlogider.Text;
                    er_Sign.Password1 = txtpasser.Password;
                    er_Sign.Password2 = txtcnfpasser.Password;
                    er_Sign.Securekey = txtsecurekeyer.Text;
                    if (!Employerbal.Register(er_Sign))
                    {
                        MessageBox.Show("Sorry Employer Registration not success");
                    }

                }
                else if (MainWindow.possition == "JobSeeker")
                {
                    Js_Sign.UserId = txtlogidjs.Text;
                    js_Sign.Password1 = txtpassjs.Password;
                    js_Sign.Password2 = txtcnfpassjs.Password;
                    js_Sign.Securekey = txtsecurekeyjs.Text;
                    Jobseekerbal.Register(js_Sign);
                    if (!Jobseekerbal.Register(js_Sign))
                    {
                        MessageBox.Show("Sorry Job Seeker Registration not success ");
                    }

                }

                ProfileFillupWindow p = new ProfileFillupWindow();
                p.Show();
                this.Close();
            }
            catch (EmployerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
