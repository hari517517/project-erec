﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using BAL;
using Exceptions;

namespace Home
{
    /// <summary>
    /// Interaction logic for ProfileFillupWindow.xaml
    /// </summary>
    public partial class ProfileFillupWindow : Window
    {

        Js_Sign js_Sign = new Js_Sign();

        Er_Sign er_Sign = new Er_Sign();

        Js_profile js_profile = new Js_profile();

        Er_profile er_profile = new Er_profile();

        EmployerBAL Employerbal = new EmployerBAL();

        JobSeekerBAL Jobseekerbal = new JobSeekerBAL();


        public ProfileFillupWindow()
        {
            InitializeComponent();
        }

        private void RichTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (MainWindow.possition == "Employer")
            {
                Erprofile.Visibility = 0;
               
            }
            else if (MainWindow.possition == "JobSeeker")
            {
                jsprofile.Visibility = 0;
            }
        }

        private void Profile_Fill_Js(object sender, RoutedEventArgs e)
        {
            try
            {
                js_profile.Name = txtfnjs.Text;
                js_profile.Experience = Convert.ToInt32(txtexpjs.Text);
                if (rbdmalejs.IsChecked == true)
                { js_profile.Gender = 'M'; }
                else if (rbdfemalejs.IsChecked == true)
                { js_profile.Gender = 'F'; }
                js_profile.Dob = Convert.ToDateTime(dobjs.Text);
                js_profile.Email = txtemailjs.Text;
                js_profile.Phone = txtphonejs.Text;
                //int a = lbskilljs.Items.Count;

                //for(int i=0;i<a;i++)
                //{ 
                //    //
                //}
                js_profile.Skills = null;
                js_profile.Address = txtaddressjs.Text;
                js_profile.Qualification = (cmbqualifijs.SelectedValue).ToString();

                if (Jobseekerbal.Profile_fill(js_profile))
                {
                    MessageBox.Show("Your Profile is successfully inserted");
                    //job seeker home page
                }
                else
                { MessageBox.Show("Sorry Your profile is not inserted"); }
                if (JobSeekerHOME.parent)
                {
                    JobSeekerHOME.parent = false;
                    JobSeekerHOME p = new JobSeekerHOME();
                    p.Show();
                }
            }
            catch (EmployerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Profile_Fill_Er(object sender, RoutedEventArgs e)
        {
            try
            {
                er_profile.CompanyName = txtcompnameer.Text;
                er_profile.Location = cmblocation.SelectedValue.ToString();
                er_profile.Clients = null;//listbox implementation
                if (Employerbal.Profile_Fill(er_profile))
                {
                    MessageBox.Show("Your Profile is successfully inserted");
                    //job seeker home page
                }
                else
                { MessageBox.Show("Sorry Your profile is not inserted"); }
            }
            catch (EmployerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerNotValidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (JobSeekerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Sign_Out_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.possition = null;
            Js_Sign.UserId = null;
            Er_Sign.UserId = null;
            MessageBox.Show("Thank You, sign out succes");
            MainWindow p = new MainWindow();
            p.Show();
        }
    }
}
