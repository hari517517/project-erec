
create database E_Recruitment_172473

use e_recruitment_172473

create schema E_rec

use  E_rec

select E_rec

-----------------------------------------------------------Job seeker signin credential table

create table E_rec.js_sign_172473
(
js_userid char(5) primary key,
js_password varchar(100) not null,
secureanswer varchar(20) not null
)

select * from E_rec.js_sign_172473


------------------------------------------------------------Employer signin credential table

create table E_rec.er_sign_172473
(
er_userid char(5) primary key,
er_password varchar(100) not null,
secureanswer varchar(20) not null
)

select * from E_rec.er_sign_172473

			   

-------------------------------------------------------------Job seeker profile details


create table E_rec.js_profile_172473
(
js_userId char(5) foreign key references E_rec.js_sign_172473(js_userid) unique,
Name varchar(20),
experience int,
gender char,
dob date,
email varchar(20),
phone char(10),
address varchar(50),
skills varchar(50),
qualification varchar(10),
photo varchar(100),
cv varchar(100)
)
----------------------------------------------------proc for Retrieve js profile 
create proc E_rec.Retrieve_JS_profile_172473
(
@js_userId char(5)
)
as
begin
    select * from E_rec.js_profile_172473 where js_userId=@js_userId	
end

-----------------------------------------------Employer profile details


create table E_rec.er_profile_172473
(
er_userid char(5) foreign key references  E_rec.er_sign_172473(er_userid) unique,
company_name varchar(30),
clients varchar(50),
location varchar(10)
)

-----------------------------------------------Job profile table

create table E_rec.job_adv_profile_172473
(
job_id char(5),
er_userid char(5),
experience int,
designation varchar(20),
location varchar(20),
qualification varchar(10),
date_of_openings date,
salary money
)


-------------------------------------job applications


create table E_rec.job_applications_172473
(
applicationid int identity(1,1),
job_id char(5),
js_userid varchar(5)
)

-------------------------------------------------------procedure for retrieve jobs
create proc E_rec.usp_retrieve_job_advs_172473
as
begin
   select * from E_rec.job_adv_profile_172473
end





---------------------------------------procedure for jobseeker check job seeker log in
create proc E_rec.usp_check_login_for_js_172473
(
@js_userid char(5) ,
@js_password varchar(100)
)
as
begin
    if exists(select * from E_rec.js_sign_172473 where js_userid=@js_userid and js_password=@js_password)
	begin
	    select 'YES' as Result
	end
	else 
	begin
	    select 'NO' as Result
	end
end

---------------------------------------procedure for jobseeker check Employer log in
create proc E_rec.usp_check_login_for_er_172473
(
@er_userid char(5) ,
@er_password varchar(100)
)
as
begin
    if exists(select * from E_rec.er_sign_172473 where er_userid=@er_userid and er_password=@er_password)
	begin
	    select 'YES' as Result
	end
	else 
	begin
	    select 'NO' as Result
	end
end

---------------------------------------procedure for jobseeker reset password 

create proc E_rec.js_rst_pswd_172473
(
@js_userid char(5),
@secure_answer varchar(20),
@newpswd varchar(100)
)
as
begin
   if(@secure_answer=(select secureanswer from E_rec.js_sign_172473 where js_userid=@js_userid))
   begin
        update  E_rec.js_sign_172473 set js_password=@newpswd  where js_userid=@js_userid		
   end   
end


------------------------------------------procedure for employer reset password

create proc E_rec.er_rst_pswd_172473
(
@er_userid char(5),
@secure_answer varchar(20),
@newpswd varchar(100)
)
as
begin
   if(@secure_answer=(select secureanswer from E_rec.er_sign_172473 where js_userid=@er_userid))
   begin
        update  E_rec.js_sign_172473 set er_password=@newpswd  where js_userid=@er_userid
   end
end


------------------------------------------procedure for update job seeker profile

create proc E_rec.er_update_profile_172473
(
@js_userId char(5),
@Name varchar(20),
@experience int,
@gender char,
@dob date,
@email varchar(20),
@phone char(10),
@address varchar(50),
@skills varchar(50),
@qualification varchar(10),
@photo varchar(100),
@cv varchar(100)
)
as
begin
     update E_rec.js_profile_172473 set
js_userId=@js_userId ,
Name=@Name ,
experience=@experience,
gender=@gender ,
dob=@dob,
email=@email ,
phone=@phone ,
address=@address ,
skills=@skills ,
qualification=@qualification ,
photo=@photo ,
cv=@cv
where js_userId=@js_userID

 end



------------------------------------------search job seeker details with js id (for employer)

create proc usp_js_search_er
(
@js_id char(5)
)
as
begin
   select * from E_rec.js_profile_172473 where js_userId=@js_id
end


------------------------------------------search jobs for job seeker and search with fields
create proc usp_job_search_for_js_172473
(
@experience int,
@designation varchar(20),
@location varchar(20),
@qualification varchar(10),
@date_of_openings date,
@salary money
)
as
begin
    select * from E_rec.job_adv_profile_172473 
    where experience=@experience and designation=@designation and location=@location and qualification=@qualification
	      and date_of_openings=@date_of_openings and salary=@salary
end






------------------------------------------update job advertisement with access of employer

create proc usp_update_job_adv
(
@job_id char(5),
@er_userid char(5),
@experience int,
@location varchar(20),
@qualification varchar(10),
@date_of_openings date,
@salary money
)
as
begin
   update E_rec.job_adv_profile_172473 set experience=@experience ,location=@location,qualification=@qualification,date_of_openings=@date_of_openings,
   salary=@salary where @job_id=@job_id and @er_userid=@er_userid
end



-------------------------------------------search job advertisement with access of employer

create proc usp_job_search_for_er
(
@job_id char(5)
)
as
begin
    select * from E_rec.job_adv_profile_172473 where job_id=@job_id
end

create table E_rec.job_adv_profile_172473
(
job_id char(5),
er_userid char(5),
experience int,
designation varchar(20),
location varchar(20),
qualification varchar(10),
date_of_openings date,
salary money
)


-------------------------------------------delete job advertisement with access of employer

create proc usp_delete_job_for_er
(
@job_id char(5),
@er_userid char(5)
)
as
begin
   delete from E_rec.job_adv_profile_172473 where job_id=@job_id and er_userid=@er_userid
end



----------------------------------------procedure for job seeker signup

create proc E_rec.js_sign_up_172473
(
@js_userid char(5),
@js_password varchar(100),
@secureanswer varchar(20)
)
as
begin
    insert into E_rec.js_sign_172473 values(@js_userid,@js_password,@secureanswer)
end


--------------------------------------procedure for employer signup

create proc E_rec.er_sign_up_172473
(
@er_userid char(5),
@er_password varchar(100),
@secureanswer varchar(20)
)
as
begin
    insert into E_rec.er_sign_172473 values(@er_userid,@er_password,@secureanswer)
end


-----------------------------------------proc for job seeker profile fillup

create proc E_rec.js_profile_fill_172473
(
@js_userId char(5),
@Name varchar(20),
@experience int,
@gender char,
@dob date,
@email varchar(20),
@phone char(10),
@address varchar(50),
@skills varchar(50),
@qualification varchar(10),
@photo varchar(100),
@cv varchar(100)
)
as
begin
     insert into E_rec.js_profile_172473 values(
@js_userId ,
@Name ,
@experience,
@gender ,
@dob,
@email ,
@phone ,
@address ,
@skills ,
@qualification ,
@photo ,
@cv )

end

----------------------------------------------proc for employer profile fillup

create proc E_rec.er_profile_fill_172473
(
@er_userid char(5) ,
@company_name varchar(30),
@clients varchar(50),
@location varchar(10)
)
as
begin
insert into E_rec.er_profile_172473 values
(
@er_userid ,
@company_name ,
@clients,
@location 
)
end



---------------------------------------------proc for apply for job

create proc usp_job_apply
(
@job_id char(5),
@js_userid varchar(5)
)
as
begin
   insert into E_rec.job_applications values(@job_id,@js_userid)
end


-----------------------------------------proc for delete application for job seeker

create proc usp_delete_job_app_js
(
@job_id char(5),
@js_userid varchar(5)
)
as
begin
     delete from E_rec.job_applications where job_id=@job_id and js_userid=@js_userid
end


------------------------------------------proc for see the applications for employer


create proc usp_see_job_applicants
(
@er_userid char(5),
@job_id char(5)
)
as
begin
     select  a.er_userid ,b.job_id ,d.* from E_rec.er_sign_172473 a,E_rec.job_adv_profile_172473 b,E_rec.job_applications c,E_rec.js_profile_172473 d
                      where a.er_userid=b.er_userid and b.job_id=c.job_id and c.js_userid=d.js_userId and a.er_userid=@er_userid and b.job_id=@job_id
end


------------------------------------------------------proc for search my applications using js id for js
create proc E_rec.usp_my_applications_js_172473
(@js_userId char(5))
as
begin
     select * from E_rec.job_applications b, E_rec.job_adv_profile_172473 a
	 where a.job_id=b.job_id  and b.js_userId=@js_userId
end